package com.acts;

public enum Course {
	DAC,
	DESD,
	VLSI
}
