package com.acts.neilsoft;

public class LongestPalindrome {
	
	public static String findPalindrome(String s) {
		int curLength = 0,  maxLength = 0;
		
		int n = s.length();
		
		String longestPalindrome = "";

		
		for(int curIndex =1;curIndex<n-1;curIndex++) {
			
			int leftIndex = curIndex-1, rightIndex = curIndex+1;
			
			while(leftIndex>=0 && rightIndex < n && s.charAt(leftIndex) == s.charAt(rightIndex)){
				leftIndex--;
				rightIndex++;
				
			}
			
			curLength = (rightIndex-1) - (leftIndex+1) + 1;
			
			if(curLength>maxLength) {
				maxLength = curLength;
				longestPalindrome = s.substring(leftIndex+1,rightIndex);
			}
			
		}
			
		return longestPalindrome;
	}
	
	public static void main(String[] args) {
		System.out.println(LongestPalindrome.findPalindrome("abcdcba"));
		
	}

}
