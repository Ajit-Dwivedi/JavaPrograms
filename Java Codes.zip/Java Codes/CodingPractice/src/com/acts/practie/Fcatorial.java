package com.acts.practie;
import java.util.*;
public class Fcatorial {
	
	
//	public static int factorialRecursion(int num) {
//		if(num==1) {
//			return 1;
//		}
//		
//		return (num * (factorialRecursion(num-1)));
//		
//	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int n = sc.nextInt();
		int res = 1;
		
		while(n>1) {
			res = res*n;
			n--;
		}
		
		System.out.println(res);
	}

}
