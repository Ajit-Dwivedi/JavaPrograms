package com.acts.practie;

import java.util.Arrays;
import java.util.Scanner;

public class Anagram {
	
	
	public static boolean isAnagran(String s1, String s2) {
		
		
		char[] ch1 = s1.toLowerCase().toCharArray();
		char[] ch2 = s2.toLowerCase().toCharArray();
		
		if(ch1.length!=ch2.length) {
			return false;
		}
		
	
		for(int i= 0;i<ch1.length;i++) {
			for(int j =0;j<ch2.length;j++) {
				if(ch2[j] == '*')
					continue;
				else if(ch1[i]==ch2[j]) {
					
					ch2[j] = '*';
					
				}
			}
		}
		
		for(int i =0;i<ch2.length;i++) {
			if(ch2[i]!='*')
				return false;
		}
		return true;
		
		
		
//		Arrays.sort(ch1);
//		Arrays.sort(ch2);
//		
//		
//		String st1 = new String(ch1);
//		String st2 = new String(ch2);
//		
//		
//		if(st1.equals(st2))
//		{
//			System.out.println("yes");
//		}
//		
//		else
//			System.out.println("no");
//		
		
		
		
//		
//		for(int i =0;i<s1.length();i++) {
//			for(int j =0;j<s2.length();j++) {
//				
//			}
//		}
//		
//		
//		return false;
//		
//		
	}
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter first String");
		
		String s1 = sc.next();
		
		System.out.println("enter second String");
		
		String s2 = sc.next();
		
		 System.out.println(Anagram.isAnagran(s1, s2));
		
		
		
	}

}
