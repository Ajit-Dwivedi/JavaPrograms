package com.acts.practie;
import java.util.*;

class Test {
    public static boolean isValid(String s) {

        Stack<Character> p = new Stack<>();

            for(int i =0;i<s.length();i++ ){
                Character ch = s.charAt(i);
                if(ch=='(' || ch=='{' || ch == '['){
                    p.push(ch);
                    continue;
                }

                   switch(ch){

                       case ')' : {
                           char ch2 = p.pop();
                           if(ch2=='{' || ch2=='['){
                               return false;
                              
                           }

                       }break;

                        case '}' : {
                           char ch2 = p.pop();
                           if(ch2=='(' || ch2=='['){
                               return false;
                              
                           }

                       }break;

                       
                        case ']' : {
                           char ch2 = p.pop();
                           if(ch2=='(' || ch2=='{'){
                               return false;
                              
                           }

                       }break;


                   }
               }
            if(!p.empty())
            	return false;

            return true;
    }


    public static void main(String[] args){
    	// System.out.println("Hello");

        System.out.println(Test.isValid("["));
        
       

    }
}


