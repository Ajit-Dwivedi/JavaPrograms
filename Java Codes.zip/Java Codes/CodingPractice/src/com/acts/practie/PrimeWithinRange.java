package com.acts.practie;

import java.util.Scanner;

public class PrimeWithinRange {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter range");
		
		int n1 = sc.nextInt();
		int n2 = sc.nextInt();
		int j,i;
		
		for(i=n1+1;i<n2;i++) {
			for(j=2;j<Math.sqrt(i);j++) {
				if((i%j)==0) {
					break;
				}
				
		}
			if(j==i) {
				System.out.println(i);
			}
		}
		
	}
	
	
	
	
	
	
	

}
