package com.acts.practie;
import java.util.*;
public class ReverseNumber {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter a number");
		
		int num = sc.nextInt();
		int rev = 0;
		int num2;
		while(num>0) {
			num2 = num%10;
			rev = (rev*10) + num2;
			num = num/10;     
		}
		
		System.out.println(rev);
	}

}
