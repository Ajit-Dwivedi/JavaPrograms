package com.acts.practie;

//q1- add - between two even and * between two odd
// q2-  find largest palindrome in string










import java.util.*;

public class Neilsoft {
	
	public static Stack stringInput(int num) {
		
		Stack<Integer> st = new Stack <Integer>();
		while(num>0) {
			int n = num%10;
			st.add(n);
			num = num/10;
		}
		
		for(int i = 0;i<st.size();i++) {
			int popedValue1 = st.pop();
			
		//	if(popedValue)
			
		}
		

		
		
		return st;
		
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println(Neilsoft.stringInput(sc.nextInt()));
		
	}

}
