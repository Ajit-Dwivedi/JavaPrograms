package com.acts.practie;
import java.util.*;
public class PrimeNumber {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter a number");
		
		int n = sc.nextInt();
		int i;
		
		for( i = 2;i<=Math.sqrt(n);i++) {
			if(n%i==0) {
				System.out.println("not a prime");
				break;
			}
		}
		
		
			
			System.out.println("prime number");
			
		
	}

}
