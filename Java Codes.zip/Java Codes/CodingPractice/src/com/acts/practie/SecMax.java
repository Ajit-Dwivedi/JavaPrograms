package com.acts.practie;

public class SecMax {
	
	public static void main(String[] args) {
		int[] arr = {1,2,3,4,5,6,7,8,9,12,11,99,97,88,1001};
		
		int max = arr[0];
		int secMax = arr[0];
		
		for(int i=0;i<arr.length;i++) {
			if(max<arr[i]) {
				secMax = max;
				max = arr[i];
				
			}
			if(max>arr[i] && secMax<arr[i]) {
				secMax = arr[i];
			}

		}
		
		System.out.println("Max :" +" "+ max);
		
		System.out.println("SecMax :" +" "+ secMax);
	}

}
