package com.acts.kratin;

public class MinElevetor {
	
	public static int elevetorCount(int[] weights) {
		int count = 0;
		int currentEleveotrWeight = 0;
		if(weights.length==1)
			return 1;
		for(int w : weights) {
			if(currentEleveotrWeight == 0) {
				currentEleveotrWeight = w;
			}
			
			else if(currentEleveotrWeight + w <=150) {
				count++;
				currentEleveotrWeight = 0;
				}
			
			else {
				count++;
				currentEleveotrWeight = w;
			}
		}
		
		if(currentEleveotrWeight != 0) {
			count++;
		}
		return count;
	}
		
	public static void main(String[] args) {
		int[] weights = {50,100,50,50,50,50};
		System.out.println(elevetorCount(weights));
	}
}
