package com.acts.itcinfo;
import java.util.*;

public class WordFrequencyCounter {
    public static void main(String[] args) {
        String sentence = "This is a sample 222 sentence. This sentence is used for demonstration purposes.";

        // Remove punctuation and convert to lowercase
        sentence = sentence.replaceAll("[^a-zA-Z ]", "").toLowerCase();
        
        System.out.println(sentence);

        // Split the sentence into words
        String[] words = sentence.split("\\s+");

        // Create a HashMap to store word frequency
        Map<String, Integer> frequencyMap = new HashMap<>();

        // Count the frequency of each word
        for (String word : words) {
            if (frequencyMap.containsKey(word)) {
                frequencyMap.put(word, frequencyMap.get(word) + 1);
            } else {
                frequencyMap.put(word, 1);
            }
        }

        // Display the word frequency
        for (Map.Entry<String, Integer> entry : frequencyMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
    }
}

