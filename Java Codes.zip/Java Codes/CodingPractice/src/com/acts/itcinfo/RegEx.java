package com.acts.itcinfo;

import java.util.*;

public class RegEx {
	
	public static void main(String[] args) {
		String s = "hi Hello Bolo. hello Hi.";
		
		 s = s.replaceAll("[^a-zA-Z ]","").toLowerCase();
		 
//		 System.out.println(s);
		 
		String[] words = s.split("\\s+");
		
//		for(String sh : words) {
//			
//			System.out.println(sh);
//			
//		}
		
		Map<String,Integer> freq = new HashMap<>();
		
		for(String str : words) {
			if(freq.containsKey(str)) {
				freq.put(str, freq.get(str)+1);
				
			}
			
			else
				freq.put(str, 1);
				
		}
		
		for(Map.Entry<String,Integer> entry : freq.entrySet())
		
		System.out.println(entry.getKey()+" :" + entry.getValue());
		
		
	}
	
	

}
