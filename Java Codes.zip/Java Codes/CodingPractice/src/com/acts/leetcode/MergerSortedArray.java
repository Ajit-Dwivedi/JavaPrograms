package com.acts.leetcode;

public class MergerSortedArray {
	
public static int[] mergeArray(int[] arr1, int[] arr2){
		
		int n1 = arr1.length;
		int n2 = arr2.length;
		int i=0, j=0, k=0;
		
		int[] result = new int[n1+n2];
		
		while()
			
		return result;
		
	}
	
	public static void main(String[] args){
		int[] array1 =new int[] {1,2,3,4};
		int[] array2 = new int[] {5,6,7,8};
		int[] result = mergeArray(array1, array2);
		
		for(int i : result ){
			System.out.println(i);
		}
		
	}

}
