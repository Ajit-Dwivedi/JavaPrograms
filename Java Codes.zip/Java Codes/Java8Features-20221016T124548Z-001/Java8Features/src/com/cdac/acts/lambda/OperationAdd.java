package com.cdac.acts.lambda;

public class OperationAdd implements Operation<Double> {

	@Override
	public Double operate(Double a, Double b) {
		return a + b;
	}
	//(Double x, Double y) -> x + y
}
