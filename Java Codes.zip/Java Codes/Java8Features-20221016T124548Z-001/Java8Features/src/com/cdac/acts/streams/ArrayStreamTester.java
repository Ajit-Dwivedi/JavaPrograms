package com.cdac.acts.streams;

import java.util.Arrays;

public class ArrayStreamTester {

	public static void main(String[] args) {
		// Create Stream<Integer> from a fixed size list
		//(un sorted ) of integers , sort
		// and display it.
		System.out.println("Sorted Values : ASC ");
		Arrays.asList(10,200,23,45,56,411,-10000)//List<Integer>
		.stream() //Stream<Integer> : Source  : unsorted stream
		.sorted() //Stream<Integer> sorted : N.O
		.forEach(i -> System.out.print("\n" +i));
		
		//DSC order 
		System.out.println("\nSorted Values : DSC ");
		Arrays.asList(10,1,23,45,75,789,-1000)//List<Integer>
		.stream() //Stream<Integer> : src  : unsorted stream
		.sorted((i1,i2) -> i2.compareTo(i1))
		.forEach(System.out::println);
		
	}

}
