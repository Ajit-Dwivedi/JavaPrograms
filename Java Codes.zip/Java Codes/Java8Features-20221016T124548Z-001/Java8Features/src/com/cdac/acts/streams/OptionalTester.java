package com.cdac.acts.streams;

import java.util.Optional;

public class OptionalTester {
	
	public static Optional<String> getString(String str) {
		return Optional.ofNullable(str);
		//Will give you empty Optional in case of null 
		//and optional with value in case of value
		
	}
	
	public static String getString1(String str) {
		return str;
	}
	
	public static void main(String[] args) {
		
//		String str = getString1(null);
//		System.out.println(str.toUpperCase());
//		
		Optional<String> optStr = getString("hello");
		optStr.ifPresent(s-> System.out.println(s.toUpperCase()));
		String str = optStr.orElse("EMPTY");
		System.out.println(str);
		//cyclomatic complexity
	}

}
