package com.cdac.acts.lambda.tester;

import com.cdac.acts.lambda.ArithmaticOperations;
import com.cdac.acts.lambda.Operation;
import com.cdac.acts.lambda.OperationAdd;
import com.cdac.acts.lambda.OperationSubstract;
public class ArithmaticOperationTester {

	public static void main(String[] args) {

		Operation<Double> operationAdd = new OperationAdd();
		Double sum = ArithmaticOperations.arithmaticOperation(
				190.20,20.20,operationAdd);
		System.out.println("Sum =" + sum);
		
		Operation<Double> operationSub = new OperationSubstract();
		Double res = ArithmaticOperations.arithmaticOperation(
				190.20,20.20,operationSub);
		System.out.println("Substraction =" + res);
		
		
		
		
		//Add 2 numbers using Anonymous Inner class
		double result = ArithmaticOperations.arithmaticOperation(
				10.20, 20.30, new Operation<Double>() {

					@Override
					public Double operate(Double a, Double b) {
						return a + b;
					}
				});

		System.out.println("Sum =" + result);


		//Add 2 numbers using Anonymous Inner class
		double result1 = ArithmaticOperations.arithmaticOperation(
				10.20, 20.30, new Operation<Double>() {

					@Override
					public Double operate(Double a, Double b) {
						return a - b;
					}
				});

		System.out.println("Substract =" + result1);
		
		
		//target is operation INterfaec   ---T operate(T a, T b);
		double result2 = ArithmaticOperations.arithmaticOperation(
				10.20, 20.30 , (x, y) -> x + y);
		System.out.println("result2 =" + result2);

	}

}
