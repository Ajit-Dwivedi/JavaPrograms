package com.cdac.acts.lambda.tester;

import com.cdac.acts.lambda.Operation;
import com.cdac.acts.lambda.OperationAdd;
import com.cdac.acts.lambda.OperationSubstract;
public class OperationTester {
	public static void main(String[] args) {

		//Add 2 numbers using Anonymous Inner class
		Operation<Double> operationAdd = new OperationAdd();
		Double sum = operationAdd.operate(190.20,20.20);
		System.out.println("Sum =" + sum);
		
		Operation<Double> operationSub = new OperationSubstract();
		Double res = operationSub.operate(190.20,20.20);
		System.out.println("Sub =" + res);
	}
}
