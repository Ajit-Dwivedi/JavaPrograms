package com.cdac.acts.lambda;

public class ArithmaticOperations {
	public static double arithmaticOperation(double d1, double d2,
			Operation<Double> operation) {
		return operation.operate(d1, d2);
		//return operationAdd.operate(190.20,20.20);
	}
}
