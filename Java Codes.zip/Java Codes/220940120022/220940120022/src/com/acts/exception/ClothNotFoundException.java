package com.acts.exception;

public class ClothNotFoundException extends Exception {
	
	public ClothNotFoundException(String msg) {
		super(msg);
	}

}
