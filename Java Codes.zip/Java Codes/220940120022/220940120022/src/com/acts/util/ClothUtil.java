package com.acts.util;
import com.acts.fashioncompany.*;
import com.acts.exception.*;

import java.time.LocalDate;
import java.util.List;

import com.acts.enums.ClothCategory;
import com.acts.enums.Size;

public class ClothUtil {
	
	public static ECommerceCompany updateStock(List<ECommerceCompany> Ecc, String brand) throws ClothNotFoundException {
		
		for(ECommerceCompany ecom : Ecc) {
			if(ecom.getBrand().equalsIgnoreCase(brand)) {
				return ecom;
			}
		}
		
		throw new ClothNotFoundException(" Cloth Not Found");
	}
	
	public static void setDiscount(List<ECommerceCompany> Ecc, String brand,ClothCategory cltegory, Double discount) throws  ClothNotFoundException{
		

		for(ECommerceCompany ecom : Ecc) {
			if(ecom.getBrand().equalsIgnoreCase(brand) && ecom.getCategory().equals(cltegory)) {
				ecom.setDiscount(ecom.getPrice() - (ecom.getPrice()* discount*0.01));
			}
		}
		
		throw new ClothNotFoundException(" Cloth Not Found");

		
		
		
		
		
	}
	
	public static ECommerceCompany removeClothes(List<ECommerceCompany> Ecc, String brand, LocalDate lastdate) throws ClothNotFoundException{
		
		LocalDate Today = null;;
		

		for(ECommerceCompany ecom : Ecc) {
			if(lastdate.isBefore(Today.now())){
				return ecom;
				
			}
		}
		throw new ClothNotFoundException(" Cloth Not Found");
		
		
		
		
		
	}
	
	public static ECommerceCompany listOutClothes(List<ECommerceCompany> Ecc, String brand) throws ClothNotFoundException {
		
	
		for(ECommerceCompany ecom : Ecc) {
			if(ecom.getStocks()<=0){
				return ecom;
				
			}
		}
		
		throw new ClothNotFoundException(" Cloth Not Found");
		
	}
	
	

}
