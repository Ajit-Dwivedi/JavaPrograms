package com.acts.fashioncompany;
import com.acts.enums.*;
import java.time.*;
public class ECommerceCompany {
	
	private static Integer id = 0;
	ClothCategory category;
	private Integer stocks;
	LocalDate stockUpdatDate;
	Size size;
	private Double price;
	private String brand;
	private String color;
	private Double discount;
	
	

	public ECommerceCompany(ClothCategory category, Integer stocks, LocalDate stockUpdatDate, Size size, Double price,
			String brand, String color, Double discount) {
		super();
		this.category = category;
		this.stocks = stocks;
		this.stockUpdatDate = stockUpdatDate;
		this.size = size;
		this.price = price;
		this.brand = brand;
		this.color = color;
		this.discount = discount;
	}

	
	


	public static Integer getId() {
		return id;
	}


	public static void setId(Integer id) {
		ECommerceCompany.id = id;
	}


	public ClothCategory getCategory() {
		return category;
	}


	public void setCategory(ClothCategory category) {
		this.category = category;
	}


	public Integer getStocks() {
		return stocks;
	}


	public void setStocks(Integer stocks) {
		this.stocks = stocks;
	}


	public LocalDate getStockUpdatDate() {
		return stockUpdatDate;
	}


	public void setStockUpdatDate(LocalDate stockUpdatDate) {
		this.stockUpdatDate = stockUpdatDate;
	}


	public Size getSize() {
		return size;
	}


	public void setSize(Size size) {
		this.size = size;
	}


	public Double getPrice() {
		return price;
	}


	public void setPrice(Double price) {
		this.price = price;
	}


	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	public Double getDiscount() {
		return discount;
	}


	public void setDiscount(Double discount) {
		this.discount = discount;
	}
	


	@Override
	public String toString() {
		return "ECommerceCompany [category=" + category + ", stocks=" + stocks + ", stockUpdatDate=" + stockUpdatDate
				+ ", size=" + size + ", price=" + price + ", brand=" + brand + ", color=" + color + ", discount="
				+ discount + "]";
	}
	
	
	
	

}
