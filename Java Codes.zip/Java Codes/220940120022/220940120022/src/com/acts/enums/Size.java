package com.acts.enums;

public enum Size {
	
	S,M,L,XL

};
