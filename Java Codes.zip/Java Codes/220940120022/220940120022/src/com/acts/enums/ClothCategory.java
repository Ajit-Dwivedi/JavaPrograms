package com.acts.enums;

public enum ClothCategory {
	
	MENS_TSHIRT,
	MENS_SHIRTS,
	WOMENS_JEANS

};
