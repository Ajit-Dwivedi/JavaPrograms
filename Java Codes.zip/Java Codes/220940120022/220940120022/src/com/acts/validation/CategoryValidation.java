//package com.acts.validation;
//import com.acts.enums.*;
//public class CategoryValidation {
//	
//	public static ClothCategory categoryValidation(String category) {
//		
//		if() {
//		ClothCategory cat = ClothCategory.valueOf(category);
//	}
//}
	
		
		
		
		
		
		
	
	

