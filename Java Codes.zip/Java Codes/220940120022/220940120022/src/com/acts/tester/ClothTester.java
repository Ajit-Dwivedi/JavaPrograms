package com.acts.tester;
import com.acts.enums.ClothCategory;
import com.acts.enums.Size;
import com.acts.exception.ClothNotFoundException;
import com.acts.fashioncompany.*;
import com.acts.util.ClothUtil;
//import com.acts.validation.CategoryValidation;

import java.time.LocalDate;
import java.util.*;
import java.util.Scanner;

public class ClothTester {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		List<ECommerceCompany> cloth = new ArrayList<>();
		int choice = 0;
		
		do {
			
			System.out.println("1.Add New Cloth"+
			                   "2.Update Stock For"+
					           "3.Set Discount"+
			                   "4.Remove Clothes"+
					           "5.List Out Clothes which are out Of Stock");
			
			System.out.println("Enter Your Choice");
			choice = sc.nextInt();
			
			
//			ClothCategory category;
//			private Integer stocks;
//			LocalDate stockUpdatDate;
//			Size size;
//			private Double price;
//			private String brand;
//			private String color;
//			private Double discount;
			switch(choice) {
			case 1:{
				
				System.out.println("Please enter Cloth Category");
				String cat = sc.next();
				
				ClothCategory category = ClothCategory.valueOf(cat);
				
				System.out.println("Enter Stocks");
				Integer stock = sc.nextInt();
				
				System.out.println("Enter Stock Upadte Date in YYYY-MM-DD format");
				String date = sc.next();
				LocalDate  upadeDate = LocalDate.parse(date);
				
				System.out.println("Enter Size");
				String size1 = sc.next();
				Size size = Size.valueOf(size1);
				
				System.out.println("Enter cloth Price");
				Double price  = sc.nextDouble();
				
				System.out.println("Enter Brand");
				String brand = sc.next();
				
				System.out.println("Enter Color");
				String color = sc.next();
				
				System.out.println("Enter Discount");
				Double discount = sc.nextDouble();
				
				cloth.add(new ECommerceCompany(category,stock,upadeDate,size,price,brand,color,discount));
				System.out.println("Cloth Added Successfully!");
				
			}break;
			
			case 2:{
				
				System.out.println("Upadte Stock For a cloth\n");
				
				System.out.println("Enter Brand");
				String brand = sc.next();
				ECommerceCompany stocks;
				
				
				try {
					stocks = ClothUtil.updateStock(cloth,brand);
					System.out.println("Enter new stocks");
					int newstock = sc.nextInt();
					
					stocks.setStocks(newstock);
					
				} catch (ClothNotFoundException e) {
					
					e.printStackTrace();
				}
						
			}break;
			
			case 3:{
				System.out.println("Please enter Cloth Category");
				String cat = sc.next();
				
				ClothCategory category = ClothCategory.valueOf(cat);
				System.out.println("Enter Brand");
				String brand = sc.next();
				
				ECommerceCompany stocks;
				
				try {
					System.out.println("Enter disccount on specific brand");
					
					System.out.println("Enter Brand Name");
					String birand = sc.next();
					
					
					 Double dis = sc.nextDouble();
					 
					ClothUtil.setDiscount(cloth,birand,category,dis);
					
					

					
				} catch (ClothNotFoundException e) {
					
					e.printStackTrace();
				}
				
				
			}break;
			
			case 4:{
				
				// remove clothes 
				System.out.println("Enter Brand Name");
				String birand = sc.next();
				
				System.out.println("Enter last stock Upade date");
				
				String lastUpdateDate =  sc.next();
				
				LocalDate lastupade = LocalDate.parse(lastUpdateDate);
				
				ECommerceCompany removecloth;
				
				
				
				try {
					removecloth = ClothUtil.removeClothes(cloth,birand,lastupade);
				} catch (ClothNotFoundException e) {
					
					e.printStackTrace();
				}
				
				
				
				
				
			}break;
			
			case 5:{
				
				// remove clothes 
				System.out.println("Enter Brand Name");
				String birand = sc.next();
				
				System.out.println("Enter last stock Upade date");
				
				
				
				ECommerceCompany ListOutcloth = null;
				
				
				
				try {
					ListOutcloth = ClothUtil.listOutClothes(cloth,birand);
				} catch (ClothNotFoundException e) {
					
					e.printStackTrace();
					
		
				}
				
				cloth.remove(ListOutcloth);
				
				
				
				
				
				
			}
			
			
			
			}
			
		}while(choice!=0);
		
		
	}

}
