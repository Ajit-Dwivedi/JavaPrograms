package com.cdac.test;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import com.cdac.validator.SpaceValidator;

public class SpaceValidatorTest {

	public static void main(String[] args) {
		String strPunctuationMarks ="! , : ; ?";
		List<String> punctuationList = new ArrayList<String>(Arrays.asList(strPunctuationMarks.split(" ")));
		String input ="Hi! how are you?Should we meet,and discuss,about:technology";
		String expectedOutput ="Hi! how are you? Should we meet, and discuss, about: technology";
		SpaceValidator validator = new SpaceValidator();
		String actualOutput = validator.validate(input, punctuationList);
		if(actualOutput.equals(expectedOutput)) {
			System.out.println("Successful");
		}
		

	}

}
