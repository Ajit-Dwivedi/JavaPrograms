package com.cdac.validator;

import java.util.List;


public class SpaceValidator {
	public static final String SPACE=" ";
	
	public String validate(String input, List<String> punctuationList)
	{
		StringBuilder sBuilder = new StringBuilder(input);
		for(int index =0 ; index < sBuilder.length(); index++)
		{
			String  str = sBuilder.substring(index, index+1);
			if(punctuationList.contains(str))
			{
				char nextChar = sBuilder.charAt(index+1);
				if(nextChar!= ' ')
				{
					sBuilder.insert(index+1,' ');
				}

			}
		}
		return sBuilder.toString();
	}	
}
