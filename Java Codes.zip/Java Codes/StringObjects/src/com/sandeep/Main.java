package com.sandeep;

class Main{
	public static boolean checkBalance(int[] arr){
		int leftsum = 0;
		int rightsum = 0;
		
		if(arr.length == 1){
			return false;
		}
		for(int i = 0; i<arr.length; i++ ){
			leftsum = leftsum+arr[i];
			rightsum = 0;
			for(int j = i+1; j<arr.length; j++){
				rightsum = rightsum + arr[j];
				
			}
			
			if(leftsum == rightsum){
				return true;
				
			}
			
		}
		
		return false;
		
	}
	
	public static void main(String[] args){
		boolean b = checkBalance(new int[] {10,10,10,10});
		System.out.println(b);
	}
}
