/**
 * 
 */
/**
 * @author AJIT
 *
 */
module StringObjects {
}