package com.acts.arraysort;


public class ArraySelectionSort {
	
	int[] arr = {3,2,5,6,9,4,7,1,8};
	
	public void sortArray() {
		
		for(int i=0;i<arr.length;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]>arr[j]) {
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i] + " ");
		}
		
		
		
		
	}
	
	public static void main(String[] args) {
		ArraySelectionSort as = new ArraySelectionSort();
		as.sortArray();
	}

	
}
