package com.acts.arraysort;

public class ArrayBubbleSort {
	
	int[] arr = {5,3,2,6,9,1,4,8,7};
	
	public void bubbleSort() {
		int count = 1;
		
		while(count<arr.length) {
			for(int i = 0;i<arr.length-1;i++) {
				if(arr[i]>arr[i+1]) {
					int temp = arr[i];
					arr[i] = arr[i+1];
					arr[i+1] = temp;
					
				}
			}
			
			count++;
		}
		for(int i = 0;i<arr.length;i++) {
			System.out.println(arr[i]+" ");
		}
		
	}
	
	public static void main(String[] args) {
		ArrayBubbleSort abs = new ArrayBubbleSort();
		abs.bubbleSort();
		
	}

}
