package com.acts.hierarchicalinheritance;

public class Car extends Vehicle {
	
	private double mileage;
	private int seatingCapacity;
	private double bootCapacity;
	
	private Driver dr;

	public Car(String type, String fuel, String colour, double mileage, int seatingCapacity, double bootCapacity,
			Driver dr) {
		super(type, fuel, colour);
		this.mileage = mileage;
		this.seatingCapacity = seatingCapacity;
		this.bootCapacity = bootCapacity;
		this.dr = dr;
	}

	@Override
	public String toString() {
		return "\nCar : " + super.toString()+ " mileage=" + mileage + ", seatingCapacity=" + seatingCapacity + ", bootCapacity=" + bootCapacity
				 + dr.toString() ;
	}

	
	
	

}
