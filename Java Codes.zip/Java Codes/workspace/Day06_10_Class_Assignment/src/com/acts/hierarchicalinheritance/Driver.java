package com.acts.hierarchicalinheritance;

public class Driver {
	
	private String name;
	private String licenceType;
	private String experience;
	
	
	public Driver(String name ,String licenceType, String experience) {
		super();
		this.name = name;
		this.licenceType = licenceType;
		this.experience = experience;
	}


	@Override
	public String toString() {
		return "\nCar's Driver Detail: name ="+name + " licenceType=" + licenceType + ", experience=" + experience;
	}
	
	
	
	
	
	

}
