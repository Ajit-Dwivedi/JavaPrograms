package com.acts.hierarchicalinheritance;

public class Bike extends Vehicle{
	
	private String absSystem;
	private int maxSpeed;
	
	
	public Bike(String type, String fuel, String colour, String absSystem, int maxSpeed) {
		super(type, fuel, colour);
		this.absSystem = absSystem;
		this.maxSpeed = maxSpeed;
	}


	@Override
	public String toString() {
		return "\nBike :"+ super.toString() + " absSystem=" + absSystem + ", maxSpeed=" + maxSpeed;
	}
	
	
	
	
	
	

}
