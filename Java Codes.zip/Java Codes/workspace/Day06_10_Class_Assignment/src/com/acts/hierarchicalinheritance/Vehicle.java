package com.acts.hierarchicalinheritance;

public class Vehicle {
	
	private String Type;
	private String fuel;
	private String colour;
	
	
	public Vehicle(String type, String fuel, String colour) {
		super();
		this.Type = type;
		this.fuel = fuel;
		this.colour = colour;
	}


	@Override
	public String toString() {
		return "Type=" + Type + ", fuel=" + fuel + ", colour=" + colour ;
	}
	
	
	

}
