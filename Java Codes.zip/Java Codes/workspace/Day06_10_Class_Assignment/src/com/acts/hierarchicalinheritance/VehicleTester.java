package com.acts.hierarchicalinheritance;

import java.util.Scanner;

public class VehicleTester {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter detials of Driver");
		System.out.println("enter drivers name, licence type and experience");
		Driver dr = new Driver(sc.next(),sc.next(),sc.next());
		
		System.out.println("Enter properties of car");
		System.out.println("enter car type, fule , colour,mileage,seating capacity,bootCapacity");
		Car cr = new Car(sc.next(), sc.next(), sc.next(), sc.nextDouble(), sc.nextInt(), sc.nextDouble(), dr);
		
		
		
		System.out.println("Enter properties of bike");
		System.out.println("enter bike type, fule , colour,confirm abs,max speed");
		
		Bike b1 = new Bike(sc.next(), sc.next() , sc.next(), sc.next(), sc.nextInt());
		
		System.out.println("do you want to print details then press 1");
		int n = sc.nextInt();
		if(n==1) {
			
			System.out.println(cr.toString());
			System.err.println(b1.toString());
			
		}
	
		
		
		
	}
 

}





//Driver dr = new Driver("Rajesh", "all type vehicle", "2 years");
//Car cr = new Car("Hatchback", "Petrol", "Black", 35, 5, 350, dr);
//Bike b1 = new Bike("Sports", "Electric", "Red", "Yes", 250);
//

