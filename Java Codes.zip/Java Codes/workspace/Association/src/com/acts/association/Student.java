package com.acts.association;

public class Student {
	
	private String name;
	private int rollNo;
	
	private Address add1;

	public Student(String name, int rollNo, Address add1) {
		
		this.name = name;
		this.rollNo = rollNo;
		this.add1 = add1;
	}
	
	@Override
	public String toString() {
		return "Student : name=" + name + ", rollNo=" + rollNo +
				"\n"+ add1.toString();
	}
	
	

}
