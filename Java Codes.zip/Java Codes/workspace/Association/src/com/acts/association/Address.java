package com.acts.association;

public class Address {
	private int houseNo;
	private int laneNo;
	private String city;
	
	
	public Address(int houseNo, int laneNo, String city) {
	
		this.houseNo = houseNo;
		this.laneNo = laneNo;
		this.city = city;
	}


	@Override
	public String toString() {
		return "Address : houseNo=" + houseNo + ", laneNo=" + laneNo + ", city=" + city;
	}
	
	
	
	
	

}
