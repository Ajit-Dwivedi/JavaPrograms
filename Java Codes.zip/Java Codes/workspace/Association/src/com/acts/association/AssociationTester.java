package com.acts.association;

public class AssociationTester {

	public static void main(String[] args) {
		
		  
		
		
		Address add1 = new Address(100 , 2 , "pune");
		Address add2 = new Address(102 , 3 , "bhopal");
		Address add3 = new Address(103 , 4 , "indore");
		
		
		Student st = new Student("Smita" , 001 , add1);
		System.err.println(st.toString());
		
		Student st1 = new Student("ajit", 002 , add2);
		System.out.println(st1.toString());
		
		Student st2 = new Student("anshu", 003 , add3);
		System.err.println(st2.toString());
		
		

	}

}
