package com.acts.dac.assignment1;

import java.util.*;

public class Test {
	
	

	
	
//	public static void findUnique(int[] arr) {
//		
//		List al = new ArrayList();
//		
//		for(int i : arr) {
//			al.add(i);
//		}
//		
//		for(int i =0; i<al.size();i++) {
//			if(al.get(i)=="l") {
//				continue;
//			}
//			for(int j= i+1;j<al.size();j++) {
//				if(al.get(i) == al.get(j)) {
//					al.set(i,"l");
//					al.set(j,"l");
//				}
//			}
//		}
//		
//		for(int i =0; i<al.size();i++) {
//			if(al.get(i)!="l") {
//				System.out.println(al.get(i));
//			}
//		}
//			
//		}
//       	


	public static void main(String[] args) {
//		int[] arr = {1,1,2,2,3,4,5};
//		
//		Test.findUnique(arr);
		

		byte b = 127;
		b = (byte) (b+1);
		
		System.out.println(b);
//		
	}

}
