package com.acts.compare;
import java.util.*;

public class Student implements Comparable<Student>{
	
	private Integer marks;
	private String name;
	
	
	
	
	public Student(Integer marks, String name) {
		
		this.marks = marks;
		this.name = name;
	}
	
	




	public int getMarks() {
		return marks;
	}






	public void setMarks(Integer marks) {
		this.marks = marks;
	}






	public String getName() {
		return name;
	}






	public void setName(String name) {
		this.name = name;
	}






	@Override
	public String toString() {
		return "Student [marks=" + marks + ", name=" + name + "]";
	}






	@Override
	public int compareTo(Student o1) {
		
//		if(this.getMarks() > o1.getMarks()) return -1;
//		else if(this.getMarks() < o1.getMarks()) return +1;
		 return this.getName().compareTo(o1.getName());
	}
	
	
}
