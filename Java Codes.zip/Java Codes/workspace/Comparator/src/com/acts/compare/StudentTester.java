package com.acts.compare;

import java.util.*;

public class StudentTester {

	public static void main(String[] args) {

		List<Student> students = new ArrayList<>();



		Student s1 = new Student(30, "Cohit");
		students.add(s1);
		Student s2 = new Student(75, "Eagar");
		students.add(s2);
		Student s3 = new Student(55, "Dihal");
		students.add(s3);
		Student s4 = new Student(95, "Aawan");
		students.add(s4);
		Student s5 = new Student(15, "Bejas");
		students.add(s5);


		students.forEach(System.out::println);


		Collections.sort(students);

		System.out.println("\n******Sorted by Name********\n");

		students.forEach(System.out::println);

		System.out.println("\n******Sorted by Marks decending order********\n");

		//MarksComparator mc = new MarksComparator();

		Collections.sort(students, new Comparator<Student>() {

			// Anonymous inner class concept
			@Override
			public int compare(Student o1, Student o2) {
				if(o1.getMarks() > o2.getMarks()) return -1;
				else if(o1.getMarks() < o2.getMarks()) return +1;
				else return 0; 

			}
		});

		students.forEach(System.out::println);


		System.out.println("\n******Sorted by Marks Accending order********\n");


		//MarksComparator mc = new MarksComparator();

		//		Collections.sort(students, new Comparator<Student>() {
		//			//anonymous inner class concept
		//			@Override
		//			public int compare(Student o1, Student o2) {
		//				if(o1.getMarks() > o2.getMarks()) return +1;
		//				else if(o1.getMarks() < o2.getMarks()) return -1;
		//				else return 0; 
		//
		//			}
		//		});
		
		
		
		// Using Lambda concept;
		Collections.sort(students, (o1,o2)-> {

			if(o1.getMarks() > o2.getMarks()) return +1;
			else if(o1.getMarks() < o2.getMarks()) return -1;
			else return 0; 

		});
		
		
//		Collections.sort(students, (st1,st2)-> {
//			
//			(st1>st2) ? -1 :(st2>st1)? +1 : 0
//			
//		});

		students.forEach(System.out::println);
		
	}
}
