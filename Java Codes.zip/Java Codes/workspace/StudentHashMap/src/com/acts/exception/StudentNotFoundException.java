package com.acts.exception;
import java.util.*;
public class StudentNotFoundException extends Exception{
	
	public StudentNotFoundException (String msg){
		
		super(msg);
		
	}
	
	

}
