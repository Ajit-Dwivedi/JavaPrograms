package com.acts.hashmap;
import com.acts.exception.StudentNotFoundException;
import com.acts.hashmap.*;

import java.time.LocalDate;
import java.util.*;

public class StudentTester {

	public static void main(String[] args) {

		Map<Integer , Student> student = new HashMap<Integer , Student>();

		Scanner sc = new Scanner(System.in);
		int choice = 0;

		do {

			System.out.println("1. Add Student\n" +
					"2. Print All Student\n"+ 
					"3. GetStudentByKey\n"+
					"4.Remove Student\n");

			System.out.println("Enter Your Choice");
			choice = sc.nextInt();


			switch(choice) {
			case 1: {

				System.out.println("Enter roll no.");
				int rollNO = sc.nextInt();

				System.out.println("Enter Student Name");
				String name = sc.next();

				sc.nextLine();
				System.out.println("Enter Course name");
				String course = sc.next();

				System.out.println("Enter DoB");
				String dob = sc.next();
				LocalDate Dob = LocalDate.parse(dob);



				student.put(rollNO, new Student(rollNO,name,course,Dob));



			}break;

			case 2:{

				StudentUtilClass.printStudent(student);
			}break;
			
			
			case 3:{
				System.out.println("enter roll no to get student details");
				Integer rollNo = sc.nextInt();
				
				Map.Entry<Integer, Student> s1 = null;
				try {
					s1 = StudentUtilClass.getStudent(student,rollNo );
				} catch (StudentNotFoundException e) {
					System.err.println(e);
					e.printStackTrace();
				}
				
				System.out.println(s1.getValue());
				
			}break;
			
			
			case 4:
			{
				System.out.println("enter roll no to get student details");
				Integer rollNo = sc.nextInt();
				
				Map.Entry<Integer, Student> s1 = null;
				try {
					s1 = StudentUtilClass.getStudent(student,rollNo );
				} catch (StudentNotFoundException e) {
					System.err.println(e);
					e.printStackTrace();
				}
				
				student.remove(s1.getKey());
				
				
				
			}break;



			}


		}while(choice!=0);



	}

}
