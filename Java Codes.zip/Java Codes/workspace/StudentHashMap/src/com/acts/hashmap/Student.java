package com.acts.hashmap;
import java.time.*;

public class Student {
	
	
	
	private Integer rollNo;
	private String name;
	private String courseName;
	LocalDate dob;
	
	 static final String INSTITUTE_NAME = "CDAC-PUNE";

	public Student(Integer rollNo, String name, String courseName, LocalDate dob) {
		
		this.rollNo = rollNo;
		this.name = name;
		this.courseName = courseName;
		this.dob = dob;
		
	}

	public Integer getRollNo() {
		return rollNo;
	}

	public void setRollNo(Integer rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCoureName() {
		return courseName;
	}

	public void setCoureName(String courseName) {
		this.courseName = courseName;
	}

	@Override
	public String toString() {
		return "Student Details : rollNo=" + rollNo + ", name = " + name + ", courseName=" + courseName+"  " + "DoB : " +dob +"]\n";
	}

	
	
	
	
	
	
	
	

}
