package com.acts.hashmap;
import com.acts.exception.*;
import java.util.Map;
import java.util.Set;

public class StudentUtilClass {
	
	
	public static void printStudent(Map<Integer , Student> student) {
		
		for(Map.Entry<Integer, Student> e : student.entrySet()) {
			
			System.out.println(e.getValue());
		}
	}
	
	public static Map.Entry<Integer, Student> getStudent(Map<Integer , Student> student, Integer rollNo) throws StudentNotFoundException{
		
		for(Map.Entry<Integer, Student> e : student.entrySet()) {
			
			
			if(e.getKey().equals(rollNo)) {
				
				return e;
			}
			
			
		}
		
		throw new StudentNotFoundException("Baccha nahi mila");
		
		
		
		
		
	}
	
public static Map.Entry<Integer, Student> removeStudent(Map<Integer , Student> student, Integer rollNo) throws StudentNotFoundException{
		
		for(Map.Entry<Integer, Student> e : student.entrySet()) {
			
			
			if(e.getKey().equals(rollNo)) {
				
				return e;
			}
			
			
		}
		
		throw new StudentNotFoundException("Baccha nahi mila");
		
		
		
		
		
	}
 

}
