package com.acts.exceptionhandling;

import java.util.Scanner;

public class ScannerException {
	
	public static void main(String[] args) {
		
		System.out.println("enter a number");
		Scanner sc = new Scanner(System.in);
		try {
		int  ch = sc.nextInt();
		System.out.println(ch);
		}
		catch(Exception e){
			System.out.println("enter only number");
			System.out.println(e);
			
		}
		finally {
			System.out.println("scanner close");
			sc.close();
		}
		
				
	}

}
