package com.acts.exceptionhandling;

import java.util.Scanner;

public class NumberException {
	public static void main(String[] args) {
		System.out.println("Enter 2 numbers");
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		
		try {
			int result = a/b;
			System.out.println("result :" + result);
		}
		catch(ArithmeticException ae) {
			System.out.println("enter correct number");
			System.out.println(ae);
		}
		
		catch(Exception e) {
			System.out.println("can not divide");
			System.out.println(e);
		}
		
		//System.out.println("do not enter 0 as a second number");
		sc.close();
	}

}
