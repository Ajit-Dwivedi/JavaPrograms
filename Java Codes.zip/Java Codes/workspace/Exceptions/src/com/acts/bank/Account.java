package com.acts.bank;

public class Account {
	
	private int accountNumber;
	private int accountHolderName;
	
	
	public Account(int accountNumber, int accountHolderName) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
	}
	

}
