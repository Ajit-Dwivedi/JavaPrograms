package com.acts.bank;

public class SavingsAccount extends Account {
	
	
	private double balance;
	 public static final double MIN_BALANCE = 1000;
	 
	 
	public SavingsAccount(int accountNumber, int accountHolderName, double balance) {
		super(accountNumber, accountHolderName);
		this.balance = balance;
	}
	
	public void deposit(double amount) {
		this.balance = balance + amount;
	}
	

	 
	
	 

}
