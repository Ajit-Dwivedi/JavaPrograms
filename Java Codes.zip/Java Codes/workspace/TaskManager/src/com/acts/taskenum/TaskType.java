package com.acts.taskenum;

public enum TaskType {
	
	comics,
	science,
	novel,
	english,
	hindi

}
