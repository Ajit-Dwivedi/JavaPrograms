package com.acts.tasktester;
import java.util.*;
import java.time.*;

import com.acts.exception.TaskNotFoundException;
import com.acts.pojo.*;
import com.acts.taskenum.TaskType;
import com.acts.taskutil.*;
public class TaskTester {

	public static void main(String[] args) {

		List<Task> task = new ArrayList <Task>();
//		Task task = new Task();

		Scanner sc = new Scanner(System.in);
		int choice =0;


		do {

			System.out.println("1.add new task"+
					"2.update task status"+
					"3.delete all completed task"+
					"4.display all pending task for today"+
					"5.display all pending task sorted by taskDate.");



			System.out.println("Enter your Choice");
			choice = sc.nextInt();


			switch(choice) {

			case 1: {

				System.out.println("Enter Task id");
				int taskid= sc.nextInt();

				System.out.println("Enter task name");
				String taskname  = sc.next();

				System.out.println("Enter Task Dtae in YYYY-MM-DD format");
				String taskdate = sc.next();
				LocalDate taskD = LocalDate.parse(taskdate);

				task.add(new Task(taskid,taskname,taskD));

				System.err.println("Lask Added Successfuly!");
			}break;

			case 2:{


				TaskAppUtil.showTask(task);
			}break;

			case 3:{
				System.out.println("Enter Book Name to Allot to Students");
				String name = sc.next();
				Map.Entry<String, BookApp> e = null;

				try {
					e =  TaskAppUtil.allotBook(bookApp,name);

				} catch (BookNotFoundException ee) {

					ee.printStackTrace();
				}

				e.getValue().setQuantity(e.getValue().getQuantity() - 1); 

				System.out.println("Book Has Been Alotted to student successfuly!");

			}break;


			case 4:{
				System.out.println("Enter Book Name to Allot to Students");
				String name = sc.next();
				Map.Entry<String, BookApp> e = null;

				try {
					e =  TaskAppUtil.addBook(bookApp,name);

				} catch (BookNotFoundException ee) {

					ee.printStackTrace();
				}

				e.getValue().setQuantity(e.getValue().getQuantity() + 1); 

				System.err.println("Book Has Been Added to stock successfuly!");


			}break;

			case 5:{
				System.out.println("Enter BookName To Remove From Library");

				String bookName = sc.next();
				Map.Entry<String, BookApp> e = null;

				try {
					e = TaskAppUtil.removeBook(bookApp, bookName);
				} catch (BookNotFoundException e1) {
					System.out.println(e1);
					e1.printStackTrace();
				}

				bookApp.remove(e);

				System.err.println("All books Removed Successfuly !");
				
                }
			
			default:{
				System.err.println("Invalid Input");
			}

			}


		}while(choice!=0);

	}

}
