package com.acts.pojo;
import java.time.LocalDate;
import java.util.*;

public class Task {
    private int taskId;
    private String taskName;
    private LocalDate taskDate;
    private String status;
    private boolean active;

    public Task(int taskId, String taskName, LocalDate taskDate) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.taskDate = taskDate;
        this.status = "pending";
        this.active = true;
    }
    
    public Task() {
    	
    }

    public int getTaskId() {
        return taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public LocalDate getTaskDate() {
        return taskDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}