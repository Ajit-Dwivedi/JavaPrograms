package com.acts.taskutil;

import java.util.List;
import java.util.Map;
import com.acts.exception.*;
import com.acts.pojo.Task;


public class TaskAppUtil {
	
	public static void showTask(List<Task> task) {
		
		for( Task e : task){
			
			System.out.println(e.toString());
			
			
			
		}
		
	}
		
	
public static Task addNewTask(List<Task> task , String  taskName) throws  TaskNotFoundException{ 
		
		for(Task e : task){
			
			if(e.equals(taskName)) {
				
				return e;
			}
			
		}
		
		throw new TaskNotFoundException("Task Not Found");
	
	}

public static Task removeTask(List<Task> task , String  taskName) throws  TaskNotFoundException{ 
	
	for(Task e : task){
		
		if(e.equals(taskName)) {
			
			return e;
		}
		
	}
	
	throw new TaskNotFoundException("task Not Found");

}



}
