package com.acts.arrayUtil;

public class StringArrayTester {

	public static void main(String[] args) {
		
		StringArray st = new StringArray();
		st.stringArray();
		st.searchInArray();
		st.reverseArrey();
	}

}
