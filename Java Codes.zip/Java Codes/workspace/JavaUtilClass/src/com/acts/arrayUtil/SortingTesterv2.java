package com.acts.arrayUtil;

import java.util.Arrays;
import java.util.Scanner;

public class SortingTesterv2 {

	public static void main(String[] args) {
		System.out.println("enter the no of data u want to store");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] arr = new int[n];
		System.out.println("enter your data");
		for(int i =0;i<n;i++) {
			arr[i] = sc.nextInt();
		}
		SortingIntergerArray sort = new SortingIntergerArray ();
		int[] s = sort.arraySort(arr);
		
		System.out.println(Arrays.toString(s));
		sc.close();


	}

}
