package com.acts.arrayUtil;

import java.util.*;

public class SortingIntegerArrayv2 {
	public int[] arraySort(int[] arr) {
		
		Arrays.sort(arr);

		return arr;

	}

}
