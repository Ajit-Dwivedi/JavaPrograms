package com.acts.arrayUtil;

import java.util.Arrays;
import java.util.Scanner;

public class StringArray {
	String[] string;

	public void stringArray() {
		System.out.println("enter a complete sentence");
		Scanner scanner = new Scanner(System.in);
		string = new String[5];
		//System.out.println(string.length);// 5
		int i = 0;
		for (i = 0; i < string.length; i++) {
			string[i] = scanner.next();

		}

	}

	public void searchInArray() {
		System.out.println("enter a string");
		Scanner sc = new Scanner(System.in);
		String st = sc.next();

		for (int i = 0; i < string.length; i++) {
			if (st.equals(string[i])) {
				System.out.println("string found :" + i);
				break;

			}
			System.out.println("string not found");
		}
		
	}
	
	public void reverseArrey() {
		String st = "";
		
		int last = string.length;
		
		for(int i =0;i<last;i++) {
			st = string[i];
			string[i] = string[last-i-1];
			 string[last-i-1] = st;
			
		}
		System.out.println(string);
		
		
	}
}
