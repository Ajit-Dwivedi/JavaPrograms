//package com.acts.lambda;
//
//public class OperationAdd implements ArithmaticOperation{
//	
//	public void operation(double a , double b) {
//		
//		return a+b ;
//	}
//
//}
