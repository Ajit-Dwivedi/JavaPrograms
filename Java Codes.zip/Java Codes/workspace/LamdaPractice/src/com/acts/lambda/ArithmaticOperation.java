package com.acts.lambda;
@FunctionalInterface
public interface ArithmaticOperation {
	
	public double operation(double a , double b);

}
