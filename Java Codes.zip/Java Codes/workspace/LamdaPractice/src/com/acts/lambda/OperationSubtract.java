//package com.acts.lambda;
//
//public class OperationSubtract implements ArithmaticOperation {
//	
//	public double operation(double a , double b)
//	{
//		return a-b;
//	}
//
//}
