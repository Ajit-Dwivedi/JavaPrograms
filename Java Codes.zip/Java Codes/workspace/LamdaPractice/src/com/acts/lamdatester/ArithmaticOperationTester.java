package com.acts.lamdatester;
import java.util.Scanner;

import com.acts.lambda.*;

public class ArithmaticOperationTester {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
//		
//		
		
		
		ArithmaticOperation ao = (a, b) -> {return (a+b);};
		ArithmaticOperation bo = (a, b) -> {return (a-b);};
		ArithmaticOperation co = (a,b) -> {return (a*b);};
		System.out.println("enter two number");
	     double a = sc.nextDouble();
		double b = sc.nextDouble();
		
		 double d = ao.operation(a, b);
		 double e = bo.operation(a, b);
		 double f = co.operation(a, b);
		 System.out.println("sum is : " + d);
		 System.out.println("sub is : " + e);
		 System.out.println("multi is : "+ f);
		 
		
		
		
	}

}
