package com.acts.recursion;

public class RecursionPrcatice {
	
	public static void printNumber(int num) {
		
		if(num==0) {
			return;
		}
		
		System.out.println(num);
		printNumber(num-1);		
		
		
	}
	
	public static void sumNaturalNumber(int i,int n,int sum) {
		
		if(i==n) {
			
			sum=sum+i;
			
			System.out.println(sum);
			
			return;
			
			
		}
		
		sum=sum+i;
		
		sumNaturalNumber(i+1,n,sum);
		
	}
	
	public static int printfactorial(int num) {
		
		if(num==1 || num==0) {
			
		return 1;	
			
		}
		int result = num *( printfactorial(num-1));
		
		return result;
		
	}

}
