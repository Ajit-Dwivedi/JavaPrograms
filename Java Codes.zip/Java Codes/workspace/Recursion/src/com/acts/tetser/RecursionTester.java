package com.acts.tetser;
import com.acts.recursion.*;
public class RecursionTester {
	
	public static void main(String[] args) {
		System.out.println("print number from 5 to 1\n");
		RecursionPrcatice.printNumber(5);
		
		System.out.println("print n natural number where n=100\n");
		RecursionPrcatice.sumNaturalNumber(1, 5, 0);
		
		
		System.out.println("factorial of n number\n");
		int result = RecursionPrcatice.printfactorial(5);
		System.out.println(result);
		
	}

}
