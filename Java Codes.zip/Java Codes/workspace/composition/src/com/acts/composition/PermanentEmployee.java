//package com.acts.composition;
//
//public class PermanentEmployee extends Employee {
//	
//	private double basicSalary;
//	private double totalAllowence;
//	
//
//}
