package com.acts.composition;

public class CompositionTester {
	public static void main(String[] args) {
		
	}

}
