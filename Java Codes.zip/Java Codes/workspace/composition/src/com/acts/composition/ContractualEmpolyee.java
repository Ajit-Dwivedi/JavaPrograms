//package com.acts.composition;
//
//public class ContractualEmpolyee extends Employee {
//	
//	
//	private double basicSalary;
//	private String timePeriod;
//
//
//}
