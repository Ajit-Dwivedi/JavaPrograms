package com.acts.basics;

public class StudentDetailsTester {

	public static void main(String[] args) {
		
		StudentDetails student = new StudentDetails();
		
				
		student.getStudent();
		student.findStudentDetails();
		student.countStudent();
		
	}

}
