package com.acts.basics;

import java.util.Scanner;

public class ReverseArrayTester {

	public static void main(String[] args) {
		System.err.println("enter 8 elements reverse");
		Scanner sc = new Scanner(System.in); 
		int[] arr = new int [8];
		for(int i =0;i<arr.length;i++) {
			arr[i] = sc.nextInt();
		}
		ReverseArray ra = new ReverseArray();
		ra.reverse(arr);
		sc.close();
			
		
	}

}
