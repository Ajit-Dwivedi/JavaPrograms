package com.acts.basics;

import java.util.Arrays;

public class ReverseArray {
	
	public void reverse(int[] arr){
		int temp = 0;
		for(int i=0;i<arr.length/2;i++) {
			if(arr[i] == arr[arr.length - i - 1]) {
				break;
				
			}
			else {
				temp = arr[i];
				arr[i] = arr[arr.length - i - 1];
				arr[arr.length - i - 1] = temp;
				
			}
		}
		System.err.println(Arrays.toString(arr));
		
	}

}
