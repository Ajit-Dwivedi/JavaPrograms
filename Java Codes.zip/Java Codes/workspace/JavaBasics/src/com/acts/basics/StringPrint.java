package com.acts.basics;

import java.util.Scanner;

public class StringPrint {

	public static void main(String[] args) {
		String[] s = new String[5];
		s[0] = "ajit";
		s[1] = "anshu is my love";
		s[2] = "vishal";
		s[3] = "mohit";
		s[4] = "sagar";
		
		System.out.println(s[1]);
		
		String string = "modi is a pm of india";
		System.out.println(string);
		
		System.out.println("enter string");
		Scanner sc = new Scanner(System.in);
		String st = sc.next();
		System.out.println(st);
		
		System.out.println("enter string");
		Scanner scc = new Scanner(System.in);
		String ssct = scc.nextLine();
		System.out.println(ssct);

	}

}
