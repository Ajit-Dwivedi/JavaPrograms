package com.acts.basics;

import java.util.Scanner;

public class StudentDetails {
	private int studentId;
	private String studentName;
	private int studentAge;
	private static String institute = "cdac";
	private StudentDetails[] st;
	
	

	
	public StudentDetails() {
	
		this.studentId = 0;
		this.studentName = "";
		this.studentAge = 0;
	}
	public StudentDetails(int studentId,String studentName,int studentAge) {
		this.studentId=studentId;
		this.studentName=studentName;
		this.studentAge=studentAge;

	}
	public void getStudent() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the no of students to store their details");
		int n = sc.nextInt();
		 st = new StudentDetails[n];

		for(int i=0;i<n;i++) {
			System.out.println("enter the details of student" + (i+1)+" "+"studenID"+" "+"Name"+" "+" age");
			StudentDetails st1 = new StudentDetails(sc.nextInt(),sc.next(),sc.nextInt());
			st[i] = st1;

		}
	}
		public void findStudentDetails() {
			Scanner sc = new Scanner(System.in);
		System.out.println("enter student id to find details");
		int a = sc.nextInt();
		for(int i=0;i<st.length;i++) {
		
			if(st[i].getStudentId() == a) {
				System.out.println(st[i].getString());
				break;
			}
			
			
	}
		
		
		}
		//		for(int i=0;i<n;i++) {
		//			
		//			System.out.println(st[i].getString());
		//			
		//			}
		// counting of student using 1st char;
		public void countStudent() {
			int count =0;
			Scanner sc = new Scanner(System.in);
			System.out.println("enter the 1st charecter of name");
			char ch = sc.next().charAt(0);
			for(int i=0;i<st.length;i++) {
				if(st[i].getStudentName().charAt(0)==ch) {
					count++;
				}
			}
			
			System.out.println("total number of student starting from char " + ch + " = " + count);
			
			
		}
		
		
	
	public int getStudentId() {
		return studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public String getString() {
		return ("\nid : " + studentId 
				+ "\nName : " + studentName
				+ "\nAge :" + studentAge
				+ "\ninstitute :" + institute);

	}




}
