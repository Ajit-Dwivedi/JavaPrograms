package com.acts.matix;

import java.util.Scanner;

public class MatrixTester {


	public static void main(String[] args) {
		int[][] m1 = new int[3][3];
		int[][] m2 = new int[3][3];

		Scanner sc = new Scanner(System.in);

		System.out.println("enter 9 elements of 1st matrix");
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				m1[i][j] = sc.nextInt();
			}
		}
		System.out.println("enter 9 elements of 2nd matrix");
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				m2[i][j] = sc.nextInt();
			}
		}
		Matrix.addMatrix(m1, m2);
		Matrix.matixMultiplication(m1, m2);
		sc.close();



	}

}
