package com.acts.matix;

import java.util.Arrays;

public class Matrix {


	public static void addMatrix(int[][] m1,int[][] m2) {
		
		int[][] add = new int[3][3];

		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				add[i][j] = m1[i][j] + m2[i][j];
			}



		}
//		method to print 2d array
		
		System.out.println(Arrays.deepToString(add));
//		for(int i=0;i<3;i++) {
//			for(int j=0;j<3;j++) {
//				System.out.print(add[i][j]+" ");
//			}
//			System.out.print("\n");
//		}





	}
	public static void matixMultiplication(int[][] m1,int[][] m2) {
	
		int[][] multi = new int[3][3];
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				int result =0;
				for(int k=0;k<3;k++) {
					result = result + (m1[i][k]*m2[k][j]);
				}
				multi[i][j] = result;
			}


		}
		System.out.println(Arrays.deepToString(multi));
//		for(int i=0;i<3;i++) {
//			for(int j=0;j<3;j++) {
//				System.out.print(multi[i][j]+" ");
//			}
//			System.out.print("\n");
//		}


	}


}
