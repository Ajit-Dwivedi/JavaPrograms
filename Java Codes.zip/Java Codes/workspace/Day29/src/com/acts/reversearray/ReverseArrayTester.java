package com.acts.reversearray;

import java.util.*;
public class ReverseArrayTester {

	public static void main(String[] args) {
		System.err.println("enter 8 elements reverse");
		Scanner sc = new Scanner(System.in); 
		int[] arr = new int [8];
		for(int i =0;i<arr.length;i++) {
			arr[i] = sc.nextInt();
		}
		Reversearray ra = new Reversearray();
		ra.reverse(arr);
		sc.close();
			

	}

}
