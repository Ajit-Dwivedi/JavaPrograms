package com.acts.bookstore;

import java.time.*;

import com.acts.bookenum.BookType;

public class BookApp {
	
	private String bookName;
	private BookType bookType;
	private Double price;
	private Integer quantity;
	private String auther;
	private LocalDate publishDate;
	
	
	public BookApp() {
		
	}
	
	
	public BookApp(String bookName, String bookType, Double price, Integer quantity, String auther,
			LocalDate publishDate) {
		
		this.bookName = bookName;
		this.bookType = BookType.valueOf(bookType);
		this.price = price;
		this.quantity = quantity;
		this.auther = auther;
		this.publishDate = publishDate;
	}


	public String getBookName() {
		return bookName;
	}


	public void setBookName(String bookName) {
		this.bookName = bookName;
	}


	public BookType getBookType() {
		return bookType;
	}


	public void setBookType(BookType bookType) {
		this.bookType = bookType;
	}


	public Double getPrice() {
		return price;
	}


	public void setPrice(Double price) {
		this.price = price;
	}


	public Integer getQuantity() {
		return quantity;
	}


	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}


	public String getAuther() {
		return auther;
	}


	public void setAuther(String auther) {
		this.auther = auther;
	}


	public LocalDate getPublishDate() {
		return publishDate;
	}


	public void setPublishDate(LocalDate publishDate) {
		this.publishDate = publishDate;
	}


	@Override
	public String toString() {
		return "BookApp [bookName=" + bookName + ", bookType=" + bookType + ", price=" + price + ", quantity="
				+ quantity + ", auther=" + auther + ", publishDate=" + publishDate + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
