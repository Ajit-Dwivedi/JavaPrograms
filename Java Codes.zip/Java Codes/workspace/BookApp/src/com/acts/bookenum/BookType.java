package com.acts.bookenum;

public enum BookType {
	
	comics,
	science,
	novel,
	english,
	hindi

}
