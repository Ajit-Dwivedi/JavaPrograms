package com.acts.bookutil;

import java.util.Map;
import com.acts.exception.*;
import com.acts.bookstore.BookApp;

public class BookAppUtil {
	
	public static void showBooks(Map<String , BookApp> books) {
		
		for( Map.Entry<String, BookApp> e : books.entrySet()){
			
			System.out.println(e.getValue());
			
			
			
		}
		
	}
	
	
	public static Map.Entry<String , BookApp> allotBook(Map<String , BookApp> books , String  bookName) throws  BookNotFoundException{ 
		
		for(Map.Entry<String , BookApp> e : books.entrySet()){
			
			if(e.getKey().equalsIgnoreCase(bookName)) {
				
				return e;
			}
			
		}
		
		throw new BookNotFoundException("Book Not Found");
		
		
	}
	
public static Map.Entry<String , BookApp> addBook(Map<String , BookApp> books , String  bookName) throws  BookNotFoundException{ 
		
		for(Map.Entry<String , BookApp> e : books.entrySet()){
			
			if(e.getKey().equalsIgnoreCase(bookName)) {
				
				return e;
			}
			
		}
		
		throw new BookNotFoundException("Book Not Found");
	
	}

public static Map.Entry<String , BookApp> removeBook(Map<String , BookApp> books , String  bookName) throws  BookNotFoundException{ 
	
	for(Map.Entry<String , BookApp> e : books.entrySet()){
		
		if(e.getKey().equalsIgnoreCase(bookName)) {
			
			return e;
		}
		
	}
	
	throw new BookNotFoundException("Book Not Found");

}



}
