package com.acts.booktester;
import java.util.*;
import java.time.*;
import com.acts.bookenum.BookType;
import com.acts.bookstore.*;
import com.acts.bookutil.*;
import com.acts.exception.BookNotFoundException;
public class BookTester {

	public static void main(String[] args) {

		Map<String,BookApp> bookApp = new HashMap<>();
		BookApp book = new BookApp();

		Scanner sc = new Scanner(System.in);
		int choice =0;


		do {

			System.out.println("1 Add book.\n"
					+ "2 Display All books\n"
					+ "3 Allot book to student ( quantity -1)\n"
					+ "4 Take book return ( quantity +1)\n"
					+ "5 Remove book\n"
					+ " ");



			System.out.println("Enter your Choice");
			choice = sc.nextInt();


			switch(choice) {

			case 1: {
				//				private String bookName;
				//				private BookType bookType;
				//				private Double price;
				//				private Integer quantity;
				//				private String auther;
				//				private Date publishDate;

				System.out.println("Enter book Name ");
				String bookName = sc.next();

				System.out.println("Enter Book type");
				String bookType  = sc.next();

				System.out.println("Enter Book Price");
				Double price = sc.nextDouble();

				System.out.println("Enter Book quantity");
				Integer quantity = sc.nextInt();

				System.out.println("Enter Auther Name");
				String auther = sc.next();

				System.out.println("Enter Publish Dtae in YYYY-MM-DD format");
				String pablishdate = sc.next();
				LocalDate publishD = LocalDate.parse(pablishdate);

				bookApp.put(bookName, new BookApp(bookName,bookType,price,quantity,auther,publishD));

				System.err.println("Book Added Successfuly!");
			}break;

			case 2:{


				BookAppUtil.showBooks(bookApp);
			}break;

			case 3:{
				System.out.println("Enter Book Name to Allot to Students");
				String name = sc.next();
				Map.Entry<String, BookApp> e = null;

				try {
					e =  BookAppUtil.allotBook(bookApp,name);

				} catch (BookNotFoundException ee) {

					ee.printStackTrace();
				}

				e.getValue().setQuantity(e.getValue().getQuantity() - 1); 

				System.out.println("Book Has Been Alotted to student successfuly!");

			}break;


			case 4:{
				System.out.println("Enter Book Name to Allot to Students");
				String name = sc.next();
				Map.Entry<String, BookApp> e = null;

				try {
					e =  BookAppUtil.addBook(bookApp,name);

				} catch (BookNotFoundException ee) {

					ee.printStackTrace();
				}

				e.getValue().setQuantity(e.getValue().getQuantity() + 1); 

				System.err.println("Book Has Been Added to stock successfuly!");


			}break;

			case 5:{
				System.out.println("Enter BookName To Remove From Library");

				String bookName = sc.next();
				Map.Entry<String, BookApp> e = null;

				try {
					e = BookAppUtil.removeBook(bookApp, bookName);
				} catch (BookNotFoundException e1) {
					System.out.println(e1);
					e1.printStackTrace();
				}

				bookApp.remove(e);

				System.err.println("All books Removed Successfuly !");
				
                }
			
			default:{
				System.err.println("Invalid Input");
			}

			}


		}while(choice!=0);

	}

}
