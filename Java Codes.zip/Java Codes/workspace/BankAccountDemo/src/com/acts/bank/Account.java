package com.acts.bank;
import java.time.*;
public class Account {
	
	private String accountNo;
	private String accountHolderName;
	private double balance;
	LocalDate accOpeningDate;
	
	
	public Account(String accountNo, String accountHolderName, double balance, LocalDate accOpeningDate) {
		this.accountNo = accountNo;
		this.accountHolderName = accountHolderName;
		this.balance = balance;
		this.accOpeningDate = accOpeningDate;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}


	@Override
	public String toString() {
		return "accountNo=" + accountNo + ", accountHolderName=" + accountHolderName + ", balance=" + balance
				+ ", accOpeningDate=" + accOpeningDate + "]";
	}
	
	
	

}
