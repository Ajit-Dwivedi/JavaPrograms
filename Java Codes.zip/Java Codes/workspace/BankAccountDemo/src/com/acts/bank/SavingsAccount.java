package com.acts.bank;

import java.time.LocalDate;

public class SavingsAccount extends Account{
	private double intrestRate;
	public final double MIN_BALANCE = 5000;

	
	public SavingsAccount(String accountNo, String accountHolderName, double balance, LocalDate accOpeningDate,
			double intrestRate) {
		super(accountNo, accountHolderName, balance, accOpeningDate);
		this.intrestRate = intrestRate;
	}
	
	public void withdraw(double amount) {
		if((this.getBalance()-amount)<MIN_BALANCE) {
			System.err.println("Sorry! Incufficenet Balance");
			
		}
		else {
			this.setBalance((this.getBalance()-amount));
			System.out.println("money withdrawn succcessfully !");
		}
		
	}
	
	public void deposit(double amount) {
		
		this.setBalance((this.getBalance()+amount));
		
		
	}
	
	public void addInterest() {
		double intrest = this.getBalance()*(this.intrestRate*(1/100));
		this.setBalance((this.getBalance()+intrest));
		
		
	}

	@Override
	public String toString() {
		return "SavingsAccount { " + super.toString()+ "}\n" ;
	}
	
	
	
	

	
	

	
	
	

}
