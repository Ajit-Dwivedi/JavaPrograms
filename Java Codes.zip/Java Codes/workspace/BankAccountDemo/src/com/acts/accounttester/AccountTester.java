package com.acts.accounttester;
import com.acts.bank.*;
import java.util.*;
import java.time.*;
public class AccountTester {
	
	public static void main(String[] args) {
		
	    List<Account> sbaccount = new ArrayList<>();
	    
	    LocalDate ld = LocalDate.parse("2001-10-10");
	    SavingsAccount s1 = new SavingsAccount("1234","Ajit",90000,ld,10);
	    
	    LocalDate ld1 = LocalDate.parse("2002-11-09");
	    SavingsAccount s2 = new SavingsAccount("1234","Sagar",40000,ld1,5);
	    
	    LocalDate ld2 = LocalDate.parse("2001-10-10");
	    SavingsAccount s3 = new SavingsAccount("1234","Mohit",50000,ld,3);
	    
	    LocalDate ld3 = LocalDate.parse("2001-10-10");
	    SavingsAccount s4 = new SavingsAccount("1234","Swapni",70000,ld,4);
	    
	    LocalDate ld4 = LocalDate.parse("2001-10-10");
	    SavingsAccount s5 = new SavingsAccount("1234","Vishal",60000,ld,8);
	    
	    sbaccount.add(s1);
	    sbaccount.add(s2);
	    sbaccount.add(s3);
	    sbaccount.add(s4);
	    sbaccount.add(s5);
	    
	    System.out.println(sbaccount);
	    
	    
	}
	


}
