package com.acts;

public class FoodBill {
	

	public static void add() {
		
		
		
	}

}
