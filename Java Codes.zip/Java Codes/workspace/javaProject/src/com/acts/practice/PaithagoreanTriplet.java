package com.acts.practice;
import java.util.Scanner;
public class PaithagoreanTriplet {

	public static void main(String[] args) {
		System.out.println("enter three number");
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		int y = sc.nextInt();
		int z = sc.nextInt();
	
		
		if(paitha(x,y,z))
		{
			System.out.println("paithagorean triplet");
		}
		else {
			System.out.println("not a paithagorean triplet");
			
		}
		sc.close();
		

	}
	public static boolean paitha(int x,int y,int z)
	{
		int a,b,c;
		 a = Math.max(x,Math.max(y,z));
		if(a==x)
		{
			b=y;
			c=z;
		}
		else if(a==y)
		{
			b=x;
			c=z;
			
		}
		else
		{
			b=x;
			c=y;
		}
		if((a*a)==(b*b)+(c*c))
		{
			return true;
			
		}
		else
		{
			return false;
		}
		
	}

}
