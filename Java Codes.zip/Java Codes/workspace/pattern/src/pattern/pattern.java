package pattern;
import java.util.Scanner;

public class pattern {

	public static void main(String[] args) {
		System.out.println("enter row and column");
	
		Scanner sc = new Scanner(System.in);
		int row = sc.nextInt();
		int col = sc.nextInt();
		for(int i = 1;i<=row;i++)
		{
			
			
			for(int j=1;j<=i;j++)
			{
				System.out.print("*");
			}
			
			System.out.println("\n");
	
			
			
		}
		sc.close();
		


	}

}
