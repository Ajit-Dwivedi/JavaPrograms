/**
 * 
 */
/**
 * @author AJIT
 *
 */
module pattern {
}