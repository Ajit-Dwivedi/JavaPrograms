package com.acts.matchingnumber;
import java.util.*;

public class  DuplicateNumber{
	
	
	public static void main(String[] args) {
		 HashSet<Integer> set = new HashSet<>();
		 ArrayList<Integer> list = new ArrayList<>();
		
		
		
		
		set.add(1);
		set.add(2);
		set.add(3);
		set.add(4);
		set.add(1);
		
		
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		
		System.out.println("List :" + list);
		Collections.sort(list);
		
		System.out.println("ShotedList :"+ list);
		
		boolean b =DuplicateUtil.checkDuplicate(list);
		if(b==true) {System.out.println("true");}
		else {System.out.println("false");}
		

	
		
		System.out.println("Set :" + set);
		
		
		
	}
	
	
	
}
