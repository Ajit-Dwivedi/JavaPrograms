package com.acts.groceryshop;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GroceryShop {
	private int productID;
	private String productName;
	private double productPrice;
	private int productQty;
	public static double totalBill = 0;

	public GroceryShop(int prodID, String prodName, double prodPrice, int prodQty) {
		this.productID = prodID;
		this.productName = prodName;
		this.productPrice = prodPrice;
		this.productQty = prodQty;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public int getProductQty() {
		return productQty;
	}

	public void setProductQty(int productQty) {
		this.productQty = productQty;
	}

	@Override
	public String toString() {
		return "GroceryShop [productID=" + productID + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", productQty=" + productQty + "]";
	}
	
	
}

