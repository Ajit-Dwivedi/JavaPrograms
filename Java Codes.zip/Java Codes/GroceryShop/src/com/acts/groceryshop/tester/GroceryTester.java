package com.acts.groceryshop.tester;
import com.acts.groceryshop.*;
import java.util.ArrayList;
import java.util.Scanner;
import com.acts.groceryshop.*;

public class GroceryTester {
	
	
	public static void main(String[] args) {
		
		
		



	}
}



