class DataTypes
{
      public static void main(String args[])
        {
           int l = 675675L;
           System.out.println(l);
           }
}