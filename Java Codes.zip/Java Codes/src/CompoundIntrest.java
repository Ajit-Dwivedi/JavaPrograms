import java.util.Scanner;
class CompoundIntrest
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter rate");
		double r = sc.nextDouble();
		System.out.println("Enter Time");
		int t = sc.nextInt();
		double temp = 1;
		System.out.println("Enter principal amount");
		double p = sc.nextDouble();
		for(int i=1;i<=t;i++)
		{
			temp =  temp*(1+(r/100));
		}
		double ci = (p*temp)- p;
		double sum = p+ci;
		System.out.println("compound intrest is ="+ ci);
		
		System.out.println("final amount is ="+ sum); 
	
	}
}	
		
			
	
