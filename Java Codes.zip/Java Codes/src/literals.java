class literals
{
     public static void main(String[] args)
       { 
         double f=0123;
         
          System.out.println(f);
        }
}