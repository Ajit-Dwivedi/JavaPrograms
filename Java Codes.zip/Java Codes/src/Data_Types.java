class Data_Types
{
	public static void main(String[] args)
	{
		int x = 10;
		float f = 10.0;
		double d = 123.456;
		char ch = 'a';
		System.out.printf("int vlaue = " + x);