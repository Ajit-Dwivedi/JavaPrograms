import java.util.Scanner;
class Fibonacci
{
	
	public static void fibo(int n)
	{
		int t1=0,t2=1,nextturm;
		for(int i =1;i<=n;i++)
		{
			System.out.println(t1);
			nextturm = t1+t2;
			t1 = t2;
			t2 = nextturm;
		}
	}
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number");
		int n = sc.nextInt();
		Fibonacci.fibo(n);
	
	}
}