class Addition
{
	public static void main(String[] args)
	{
		double x = Double.parseDouble(args[0]);
		double y = Double.parseDouble(args[1]);
		System.out.printf("sum=%d",(x+y));
	}
}