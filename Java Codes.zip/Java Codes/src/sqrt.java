import java.util.Scanner;
class Sqrt
{
	public static void main(String[] args)
	{
		System.out.println("enter a number to find SquareRoot");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		for(int i=1;i<=n/2;i++)
		{
			if((i*i)!=n)
			{
				continue;
			}
			else
				System.out.println("sqrt of" + " " + n + " = " + " " + i);
		}
	}
}
				
		