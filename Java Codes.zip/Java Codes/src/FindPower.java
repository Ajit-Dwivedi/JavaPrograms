import java.util.Scanner;
class FindPower
{
	public static void main(String[] args)
	{
		System.out.println("To find power of any number");
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number");
		int a = sc.nextInt();
		System.out.println("enter power");
		int n = sc.nextInt();
		int result =1;
		for (int i =1;i<=n;i++)
		{
			result = result*a;
		}
			
		System.out.println("result is = "+"  "+ result);
	}
}
		
		