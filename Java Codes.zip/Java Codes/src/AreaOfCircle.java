import java.util.Scanner;
class AreaOfCircle
{
	   class AreaCircle
	{
		
	      void area( )
		{
			Scanner sc = new Scanner(System.in);
			double r = sc.nextDouble();
			double area_is = 3.14*r*r;
			System.out.println("area of cicle is ="+ area_is);
		}
	}
	public static void main(String[] args)
	{
		
		AreaCircle ca = new AreaCircle();
		ca.area();
	}
		
			
			
	
}
		