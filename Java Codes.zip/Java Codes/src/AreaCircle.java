import java.util.Scanner;


class AreaCircle
    {
	       void area( )
		{
		 	Scanner sc = new Scanner(System.in);
			System.out.println("enter radius");
			double r = sc.nextDouble();
			double area_is = 3.14*r*r;
			System.out.println("area of cicle is ="+ area_is);
		}
		void circumference()
		{
			
		 	Scanner sc = new Scanner(System.in);
			System.out.println("enter radius");
			double r = sc.nextDouble();
			double circum = 2*3.14*r;
			System.out.println("circumference of cicle is ="+ circum);
		}
		public static void main(String[] args)
	{
		
		AreaCircle ca = new AreaCircle();
		ca.area();
		ca.circumference();
	}
	}

	
	
		
			
			
	

		