import com.acts.cdac.ArithmaticOper;
import java.util.Scanner;
class ArithmaticTester
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter two no for addition);
		int x = sc.nextInt();
		int y = sc.nextInt();
		ArithmaticOper data = new ArithmaticOper();
		
		int z = data.add(x,y);
		System.out.println("sum = "+" "+z);
	}
}