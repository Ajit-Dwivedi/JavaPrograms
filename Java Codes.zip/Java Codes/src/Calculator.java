class Calculator
{
	public static void main(String[] args)
	{
		add(20,300);
	}
	public static void add(int x,int y)
	{
		System.out.println("addition="+ (x+y));
	}
}