package com.acts.cdac;
public class ArithmaticOper
{
	public int add(int x,int y)
	{
		return (x+y);
	}
}