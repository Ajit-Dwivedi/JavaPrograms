class PracticePrint
{
	public static void main(String[] args)
	{
		int x = 100;
		float f = 123.45678f;
		char ch = 'A';
		double d = 123.456;
		System.out.println("int value = "+ x + "hello");
		System.out.println("float value = "+ f);
		System.out.println("char = "+ ch);
		System.out.println("double = "+ d);
	}
}