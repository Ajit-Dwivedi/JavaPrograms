class BinaryRipresentation
{
	public static void main(String[] args)
	{
		int x = 0b1111;
		int y = 0b0010;
		System.out.println(x+y);
	}
}
		