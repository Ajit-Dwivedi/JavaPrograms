import java.util.Scanner;
class AreaRectangle
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter length of rectangle");
		int l = sc.nextInt();
		System.out.println("enter breadth of rectangle");
		int b = sc.nextInt();
		int area = l*b;
		System.out.println("area of rectangle is = "+"  "+ area);
	}
}
		
		
		
		
		