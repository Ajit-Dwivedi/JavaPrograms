import java.io.*;
import java.util.*;



public class Solution {
    public static void main(String[] args) {
        System.out.println("enter a number");
       Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
       for(int i=1;i<=20;i++){
           int result = n*i;
           System.out.println(result);
       }
       sc.close();
    }
}
