class char
{
     public static void main(String[] args)
     {
       char ch = 0xface;
       System.out.println(ch);
      }
}