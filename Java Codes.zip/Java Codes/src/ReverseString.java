import java.util.Scanner;
class ReverseString{
	public static void main(String... args){
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a string to reverse");
		
	String s = sc.next();
	String result = "";
	for(int i=s.length()-1;i>=0;i--){
		result = result+s.charAt(i);
	}
	System.out.println(result);
 }
		
}